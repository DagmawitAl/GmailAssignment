package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {
	// write your code here
        System.setProperty("webdriver.gecko.driver", "C:\\Gecko\\geckodriver.exe");
        WebDriver driver= new FirefoxDriver();
        driver.get("http://gmail.com");
        Thread.sleep(5000);
        driver.findElement(By.name("identifier")).sendKeys("dhabtegabriel@gmail.com");
        driver.findElement(By.id("identifierNext")).click();
        Thread.sleep(5000);
        driver.findElement(By.name("password")).sendKeys(User.password);
        driver.findElement(By.id("passwordNext")).click();
        List<WebElement> emails = driver.findElements(By.className("zE"));

        File document = new File("./Emails.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(document));

        writer.write("Number of unread emails = " + emails.size() + "              \n");

        System.out.println("Number of unread emails = "+emails.size());
        for(WebElement email: emails){
            System.out.println(email.getText());
            writer.write("\n###################\n");
            writer.write(email.getText());
            writer.write("\n###################\n");
        }

        driver.quit();
    }
}
